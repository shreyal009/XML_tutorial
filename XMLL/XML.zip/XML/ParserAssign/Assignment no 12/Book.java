import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import java.io.*;
import javax.xml.parsers.*;
class Book extends  DefaultHandler
{
	static int count = 0;
	public void startDocument() throws SAXException
	{
	}
	public void startElement(String uri, String localName, String qName,
	Attributes attributes) throws SAXException 
	{
		for(int i=0; i<attributes.getLength(); i++)
		{
		if(attributes.getQName(i).equalsIgnoreCase("pubyear"))
		{
			int val = Integer.parseInt(attributes.getValue(i));
			if(val >= 1980 && val < 1990)
			{
				count++;
			}
		}
		}
	}
	
	public void endElement(String uri, String localName,
		String qName) throws SAXException {
 
	}
	
public static void main(String args[])
{
	try
	{
	SAXParserFactory factory=SAXParserFactory.newInstance();
	// create a parser
	SAXParser saxParser=factory.newSAXParser();
	// create and set event handler on the parser
	Book handler=new Book();	
	saxParser.parse(new File("book.xml"),handler);	
	System.out.println("The Total Number of books published in 1980's is = "+count);
	}
	catch(Exception e)
	{
		System.out.println("we are in "+e);
	}
}
}
