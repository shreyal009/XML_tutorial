import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
public class company
{
	public static void main(String args[]) 
	{
		String file = "company.xml";
		try {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(file));
		Element root = document.getDocumentElement();
		
		System.out.println("Root Element : "+root.getTagName());
		System.out.printf("\tCompany Name:\t\t %s%n",root.getAttribute("name"));
		System.out.printf("\tCompany Short name:\t %s%n",root.getAttribute("shortName"));
		System.out.printf("\tCompany Mission:\t %s%n",root.getAttribute("mission"));
		NodeList departments = root.getElementsByTagName("department");
		for(int i=0; i<departments.getLength(); i++) 
		{
			Element department = (Element)departments.item(i);
			System.out.println(department.getTagName());
			System.out.printf("\tCompany Name:\t\t %s%n",department.getAttribute("name"));
			System.out.printf("\tCompany Mission:\t %s%n",department.getAttribute("mission"));
			System.out.printf("\tCompany Staff:\t\t %s%n",countStaff(department));
		}
		}
		catch (Exception e) {
		e.printStackTrace();
		}
	}
	public static int countStaff(Element department)
	{
		int departmentStaff = 0;
		NodeList groups =department.getElementsByTagName("group");
		for(int i=0; i < groups.getLength(); i++) {
		Element group = (Element)groups.item(i);
		int groupStaff = Integer.parseInt(group.getAttribute("numStaff"));
		departmentStaff = departmentStaff + groupStaff;
		}
		return(departmentStaff);
	}
}