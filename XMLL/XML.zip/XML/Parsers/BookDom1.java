import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
class BookDom1
{
	public static void main(String args[])
	{
		try
		{
				DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
				DocumentBuilder db=dbf.newDocumentBuilder();
				Document doc=db.parse("book.xml");
				System.out.println("db Validating="+db.isValidating());
				Element root=doc.getDocumentElement();
				System.out.println("XMl opened successfully");
				System.out.println(root);
				
		}
		catch(Exception e)
		{
			System.out.println("Exception"+e);
		}
		
	}
}