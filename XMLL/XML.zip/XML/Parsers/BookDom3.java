import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
class BookDom3
{
	public static void main(String args[])
	{
		NodeList elements;
		String elementName="books";
		try
		{
			DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
			DocumentBuilder db=dbf.newDocumentBuilder();
			Document doc=db.parse("Book.xml");
			Node root1=doc.getDocumentElement();
			System.out.println("Root node: "+root1.getNodeName());
			System.out.println("Root node type: "+root1.getNodeType());
			Element root=doc.getDocumentElement();
			System.out.println("Xml opened ");
			elements=doc.getElementsByTagName(elementName);
			if(elements==null)
			{
				return;
			}
			int elementCount=elements.getLength();
			System.out.println("Count :"+elementCount);
			for(int i=0;i<elementCount;i++)
			{
				Element element=(Element)elements.item(i);
				System.out.println("Element Name : "+elements.item(i).getNodeName());
				System.out.println("Element Type :"+element.getNodeType());
				System.out.println("Element Value :"+element.getNodeValue());
				System.out.println("Has Attributes :"+element.hasAttributes());
				//System.out.println("Attribute name :"+element.getAttributes().getNamedItem().getNodeValue());
				/*NamedNodeMap attrvalue = element.getAttributes();
				for (int j = 0; j < attrvalue.getLength(); ++j)
				{
					Node attr = attrvalue.item(j);
					System.out.println("Attribute name :"+attr.getNodeName() + "\tValue: " + attr.getNodeValue() + "\n");
				}*/
				if(element.hasAttributes())
				{
				NamedNodeMap attrvalue = element.getAttributes();
				for (int j = 0; j < attrvalue.getLength(); ++j)
				{
					System.out.println("Attribute name :"+attrvalue.item(j).getNodeName()+"\n");
				}}
				
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception "+e);
		}
	}
}