import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;
import java.io.*;
import javax.xml.parsers.*;

class SaxDemo extends DefaultHandler {

public SaxDemo() {
}

public void startDocument() throws SAXException
{
System.out.println("Event Type: Start Document");
}

public void endDocument() throws SAXException 
{
System.out.println("Event Type: End Document");
}

public void startElement(String uri, String localName, String qName,
Attributes attributes) throws SAXException 
{
System.out.println("Event Type: Start Element : "+qName);


for (int i = 0; i < attributes.getLength(); i++) 
	{
	System.out.println("Attribute Name:" + attributes.getQName(i));
	System.out.println("Attribute Value:" + attributes.getValue(i));
	}
}

public void endElement(String uri, String localName, String qName)
throws SAXException 
{
System.out.println("Event Type: End Element : "+qName);
}

public void characters(char[] ch, int start, int length)
throws SAXException 
{
System.out.println("Event Type: Text");
String str = (new String(ch, start, length));
System.out.println(str);
}

public void ignorableWhitespace(char[] ch, int start, int end)
throws SAXException {
	System.out.println("ignoring white space");
}

//Error Handling
public void error(SAXParseException e)
throws SAXException{
System.out.println("Error: "+e.getMessage());
}

public void fatalError(SAXParseException e)
throws SAXException{
System.out.println("Fatal Error: "+e.getMessage());
}

public void warning(SAXParseException e)
throws SAXException{
System.out.println("Warning: "+e.getMessage());
}

public static void main(String args[])
	{
	try
	{
	SAXParserFactory factory=SAXParserFactory.newInstance();

	// create a parser
	SAXParser saxParser=factory.newSAXParser();

	// create and set event handler on the parser
	SaxDemo handler=new SaxDemo();	
	saxParser.parse(new File("book.xml"),handler);			
	}
	catch(Exception e)
	{
		System.out.println("we are in "+e);
	}
	}
}
